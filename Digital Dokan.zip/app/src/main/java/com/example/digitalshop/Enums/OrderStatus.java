package com.example.digitalshop.Enums;

public enum  OrderStatus
{
    PROCESSING,
    SHIPPED,
    DELIVERED,
    CANCELLED

}
