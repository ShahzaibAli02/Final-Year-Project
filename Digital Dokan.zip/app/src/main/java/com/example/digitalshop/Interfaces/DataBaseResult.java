package com.example.digitalshop.Interfaces;

public  interface DataBaseResult
{

      void  onResult(boolean error,String Message,Object data);
}
