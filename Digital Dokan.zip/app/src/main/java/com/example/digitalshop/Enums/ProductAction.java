package com.example.digitalshop.Enums;

public enum  ProductAction
{
    DELETE,
    UPDATE,
    ADD
}
