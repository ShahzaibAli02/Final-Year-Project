package com.example.digitalshop.Interfaces;

public interface ImageUploadListener
{
    public  void  onUpload(boolean error,String Message,String url);

}
