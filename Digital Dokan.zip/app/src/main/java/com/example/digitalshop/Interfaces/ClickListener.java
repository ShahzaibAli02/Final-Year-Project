package com.example.digitalshop.Interfaces;

public interface ClickListener
{

    public  void  onClicked(int position);
}
