package com.example.digitalshop.Utils;

public class Constants
{

    public  static  String DB_USERS="Users";
    public  static  String DB_PRODUCTS="PRODUCTS";
    public  static  String DB_ORDERS="ORDERS";
    public  static  String DB_ANALYTICS="Analytics";

}
